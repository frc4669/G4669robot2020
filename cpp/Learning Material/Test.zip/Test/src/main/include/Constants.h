/*----------------------------------------------------------------------------*/
/* Copyright (c) 2019 FIRST. All Rights Reserved.                             */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

#pragma once
namespace OIConstants {
    constexpr int kF310 = 0;
}

namespace DriveConstants {
    constexpr int kLeftMotorPort = 1;
    constexpr int kRightMotorPort = 0;

    constexpr double wheelDiameter = 6;
    constexpr int ticksPerRev = 4096;
    constexpr int originalGear = 20;
    constexpr int driveGear = 10;
    constexpr double wheelCircum = wheelDiameter * M_PI;
    constexpr double gearRatio = originalGear / driveGear;
    constexpr double wheelTicksPerRev = ticksPerRev * gearRatio;
    constexpr double ticksToIn = wheelTicksPerRev / ticksPerRev;
    constexpr double inToTicks = wheelCircum * wheelTicksPerRev;
}
/**
 * The Constants header provides a convenient place for teams to hold robot-wide
 * numerical or boolean constants.  This should not be used for any other
 * purpose.
 *
 * It is generally a good idea to place constants into subsystem- or
 * command-specific namespaces within this header, which can then be used where
 * they are needed.
 */
